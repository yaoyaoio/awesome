core.register_service("donothing", "http", function(applet) end)
